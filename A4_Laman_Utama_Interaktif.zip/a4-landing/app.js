// Tetapkan pautan selepas halaman peta misi dan menu Mod A disediakan.
const MISSION_URL = 'peta-misi.html';
const MOD_A_URL = '../index.html';
const form = document.getElementById('studentForm');
const nameInput = document.getElementById('nama');
const classInput = document.getElementById('kelas');
const hint = document.getElementById('hint');
try { const saved = JSON.parse(localStorage.getItem('a4_student') || '{}'); nameInput.value = saved.nama || ''; classInput.value = saved.kelas || ''; } catch {}
form.addEventListener('submit', e => {
 e.preventDefault();
 const nama = nameInput.value.trim(), kelas = classInput.value.trim();
 if (!nama || !kelas) { hint.textContent = 'Sila isi nama dan kelas dahulu!'; return; }
 localStorage.setItem('a4_student', JSON.stringify({nama,kelas}));
 // Elakkan pautan rosak jika halaman misi belum dibina.
 fetch(MISSION_URL,{method:'HEAD'}).then(r=>{if(!r.ok)throw Error();location.href=MISSION_URL;}).catch(()=>{hint.textContent='Maklumat disimpan! Halaman peta misi A4 perlu dibangunkan dahulu.';});
});
const guide=document.getElementById('guide');document.getElementById('how').addEventListener('click',()=>guide.showModal());document.getElementById('closeGuide').addEventListener('click',()=>guide.close());
document.getElementById('back').addEventListener('click',()=>{location.href=MOD_A_URL;});
